import 'dart:ui';

var anaRenk = const Color(0xFFCB2020);
var yaziRenk1 = const Color(0xFFFFFFFF);
var yaziRenk2 = const Color(0xFF636363);
