package com.example.tasarim_calismasi1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
